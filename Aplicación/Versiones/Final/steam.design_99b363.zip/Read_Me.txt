To upload the images provided in this .zip, you must follow the guide listed below. Images uploaded without using the guide listed will appear short and squished.
https://steamcommunity.com/sharedfiles/filedetails/?id=748624905

If this is your first time using long images, then you will need to remove two of the three images on the right. To do so, select the same image for all three boxes and it will remove two of them.

Thank you for using from steam.design. If you require support of any kind, bug reporting, or just wish to chat, feel free to join our discord.
https://discord.gg/jnqnHuX